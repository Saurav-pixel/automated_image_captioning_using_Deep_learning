# Automatic-Image-Captioning
Here I have implemented a first-cut solution to the Image Captioning Problem, i.e. Generating Captions for the given Images using Deep Learning methods.

For more detailed explanation, please refer my blog on Medium: https://medium.com/@harshall.lamba/image-captioning-with-keras-teaching-computers-to-describe-pictures-c88a46a311b8
